package com.example.medialplayer_h2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.medialplayer_h2.databinding.ItemLayoutBinding
import com.example.medialplayer_h2.model.Song

class SongAdapter : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {
    lateinit var onClick: (Song) -> Unit
    private var songList = mutableListOf<Song>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        return SongViewHolder(
            ItemLayoutBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        holder.bind(songList[position])
    }

    override fun getItemCount(): Int = songList.size

    inner class SongViewHolder(private val binding: ItemLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(song: Song) {
            binding.apply {
                binding.foodName.text = song.name
                binding.foodCountry.text = song.author
                binding.img.setImageResource(song.img)
                floatingActionButton.setOnClickListener {
                    onClick(song)
                }
            }
        }

    }

    fun setList(foodEntity: MutableList<Song>) {
        this.songList = foodEntity
        notifyDataSetChanged()
    }
}