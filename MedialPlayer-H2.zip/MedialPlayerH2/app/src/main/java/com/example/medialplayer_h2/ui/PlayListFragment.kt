package com.example.medialplayer_h2.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.medialplayer_h2.R

import com.example.medialplayer_h2.databinding.FragmentPlayListBinding

class PlayListFragment : Fragment(R.layout.fragment_play_list) {
    private var _binding: FragmentPlayListBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentPlayListBinding.bind(view)


        allCode()
    }

    private fun allCode() {

    }
}