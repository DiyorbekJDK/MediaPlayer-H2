package com.example.medialplayer_h2.ui.dashboard

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.MediaController

import androidx.fragment.app.Fragment
import com.example.medialplayer_h2.R
import com.example.medialplayer_h2.databinding.FragmentDashboardBinding


class DashboardFragment : Fragment(R.layout.fragment_dashboard) {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentDashboardBinding.bind(view)


        allCode()
    }

    private fun allCode() {
        val mediaController = MediaController(requireContext())
        mediaController.setAnchorView(binding.videoView)
        binding.videoView.setVideoURI(Uri.parse("android.resource://${requireContext().packageName}/${R.raw.video}"))
        binding.videoView.setMediaController(mediaController)
        binding.videoView.start()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}