package com.example.medialplayer_h2.ui

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.Toast
import com.example.medialplayer_h2.R
import com.example.medialplayer_h2.databinding.FragmentDiscoBinding
import com.example.medialplayer_h2.model.Song
import java.text.SimpleDateFormat
import java.util.*

class DiscoFragment : Fragment(R.layout.fragment_disco) {
    private var _binding: FragmentDiscoBinding? = null
    private val binding get() = _binding!!
    private var txt: String = "start"
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var handler: Handler
    private lateinit var music: Song
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentDiscoBinding.bind(view)

        music = arguments?.getParcelable("song")!!
        allCode()
        handler = Handler(Looper.getMainLooper())

    }

    private fun allCode() {
        binding.btnPlay.setOnClickListener {
            repeatingPress()
        }
        if (music == null){
            Toast.makeText(requireContext(), "it is empty", Toast.LENGTH_SHORT).show()
        }else{
            binding.imageView3.setImageResource(music.img)
            binding.textView5.text = music.name
            binding.textView6.text = music.author
        }

    }

    private fun repeatingPress() {
        if (binding.btnPlay.drawable
                .constantState == resources.getDrawable(R.drawable.baseline_play_circle_outline_24)
                .constantState && txt == "start"
        ) {
            binding.btnPlay.setImageResource(R.drawable.baseline_pause_circle_outline_24)
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.music)
                handler.postDelayed(runnable, 100)
                mediaPlayer?.start()
                txt = "play"
                binding.seekBar.max = mediaPlayer?.duration!!
                binding.allTime.text = setCurPlayTimeToTextView(mediaPlayer?.duration!!.toLong())
            }
        } else if (binding.btnPlay.drawable
                .constantState == resources.getDrawable(R.drawable.baseline_play_circle_outline_24)
                .constantState && txt == "play"
        ) {
            if (!mediaPlayer?.isPlaying!!) {
                mediaPlayer?.start()
                binding.btnPlay.setImageResource(R.drawable.baseline_pause_circle_outline_24)
            }
        } else if (binding.btnPlay.drawable
                .constantState == resources.getDrawable(R.drawable.baseline_pause_circle_outline_24)
                .constantState
        ) {
            if (mediaPlayer?.isPlaying!!) {
                mediaPlayer?.pause()
                binding.btnPlay.setImageResource(R.drawable.baseline_play_circle_outline_24)
            }
        } else {
            binding.btnPlay.setImageResource(R.drawable.baseline_play_circle_outline_24)
        }
    }

    private var runnable = object : Runnable {
        override fun run() {
            handler.postDelayed(this, 100)
            try {
                binding.seekBar.progress = mediaPlayer?.currentPosition!!
                binding.currentTime.text =
                    setCurPlayTimeToTextView(mediaPlayer?.currentPosition!!.toLong())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun setCurPlayTimeToTextView(ms: Long): String {
        val dateFormat = SimpleDateFormat("mm:ss", Locale.getDefault())
        return dateFormat.format(ms)
    }
}