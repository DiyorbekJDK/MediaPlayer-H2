package com.example.medialplayer_h2.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Song(
    val img: Int,
    val name: String,
    val author: String
): Parcelable
