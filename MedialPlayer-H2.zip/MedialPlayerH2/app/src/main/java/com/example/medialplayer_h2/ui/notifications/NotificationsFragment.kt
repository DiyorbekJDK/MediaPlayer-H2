package com.example.medialplayer_h2.ui.notifications

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medialplayer_h2.R
import com.example.medialplayer_h2.adapter.SongAdapter
import com.example.medialplayer_h2.databinding.FragmentNotificationsBinding
import com.example.medialplayer_h2.util.Constantas

class NotificationsFragment : Fragment(R.layout.fragment_notifications) {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!
    private val adapter2 = SongAdapter()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentNotificationsBinding.bind(view)


        allCode()
    }

    private fun allCode() {
        binding.rv.apply {
            adapter = adapter2
            layoutManager = LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
        }
        adapter2.setList(Constantas.list())
        adapter2.onClick = {
            val bundle = bundleOf("song" to it)
            findNavController().navigate(
                R.id.action_navigation_notifications_to_navigation_disco,
                bundle
            )
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}