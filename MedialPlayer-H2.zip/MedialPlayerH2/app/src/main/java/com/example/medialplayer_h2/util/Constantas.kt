package com.example.medialplayer_h2.util

import com.example.medialplayer_h2.R
import com.example.medialplayer_h2.model.Song

object Constantas {
    fun list(): MutableList<Song> {
        return mutableListOf(
            Song(R.drawable.stark, "Stark", "Tony Stark"),
            Song(R.drawable.first_singer, "Dont look at me!", "Kotlinjon"),
            Song(R.drawable.second_singer, "Men mos man", "Pushkin"),
            Song(R.drawable.third_singer, "Salom Hamaga", "Ketmonjon"),
            Song(R.drawable.singers, "Singers Group", "Boys"),
        )
    }
}